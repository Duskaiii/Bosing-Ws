/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bosing.unimed.ws.service;

import com.bosing.unimed.ws.repositories.MedicoRepository;

/**
 *
 * @author Dzkyy
 */
public class MedicoService {
    
    public ArrayList<Medico> findAll(){
        
        try{
            MedicoRepository medicoRepository = new MedicoRepository();
            return medicoRepository 
        }
    }
    
}
