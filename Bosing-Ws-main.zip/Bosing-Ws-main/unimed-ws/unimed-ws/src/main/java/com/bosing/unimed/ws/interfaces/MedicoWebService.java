/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.bosing.unimed.ws.interfaces;

import com.bosing.unimed.ws.exceptions.ValidaException;
import com.bosing.unimed.ws.model.Medico;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author muril
 */
public interface MedicoWebService {
   
   @WebMethod
   Medico findById(@WebParam int id) throws ValidaException;
   
   
   @WebMethod
   Medico inserir(Medico medico) throws ValidaException;
   
   @WebMethod
   Medico atualizar(Medico medico)throws ValidaException;
   
   @WebMethod
   void deletar (int id);
   
   @WebMethod
   void inativar(int id);
    
}
